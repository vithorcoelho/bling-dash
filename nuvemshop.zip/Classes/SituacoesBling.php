<?php

class SituacoesBling {

	public $apikey = API_KEY;
	public $urlapi = API_URL . 'situacao';
	public $modulo = 'Vendas';
	public $outputType = "json";

	public function getUrlCurl()
	{
		$urlcurl = "{$this->urlapi}/{$this->modulo}/{$this->outputType}/&apikey={$this->apikey}";
		
		$this->urlcurl = $urlcurl;

		return $this->urlcurl;
	}

	public function listSituacao()
	{
		$curl_handle = curl_init();
	    curl_setopt($curl_handle, CURLOPT_URL,  $this->getUrlCurl() );
	    curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, TRUE);
	    $response = curl_exec($curl_handle);
	    curl_close($curl_handle);

	    $allsituacao = $response;
		$allsituacao = json_decode($allsituacao, true);
		$return = [];

		foreach ($allsituacao['retorno']['situacoes'] as $key => $value)
		{
			$return[] = array(
				'nome' 			=> $value['situacao']['nome'],
				'id'	=> $value['situacao']['id'],
				'idHerdado'		=> $value['situacao']['idHerdado']);
		}

		return $return;
	}

	public function getIdsHerdados(array $id)
	{
		$idsHerdado = [];

		foreach ($id as $id)
		{
			foreach ($this->listSituacao() as $idHerdado)
			{
				if($idHerdado['idHerdado'] == $id)
				{
					$idsHerdado[] = $idHerdado['id'];
				}
			}

			$idsHerdado[] = $id;

		}

		return $idsHerdado;
	}
}
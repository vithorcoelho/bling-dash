<?php 

class PedidosBling

{
	public $apikey = API_KEY;
	public $urlapi = 'https://bling.com.br/Api/v2/pedidos';
	public $outputType = 'json';
	public $filters;
	public $urlcurl;
	public $page = 1;

	public function setFilterSituacao(array $id)
	{
		$filtersituacao = '';

		foreach ($id as $value)
		{
			$filtersituacao .= $value . ',';
		}

		$filtersituacao = substr($filtersituacao, 0, -1);

		if($this->filters)
		{
			$this->filters = $this->filters . ';idSituacao[' . $filtersituacao . ']';
		}
		else
		{
			$this->filters = 'idSituacao[' . $filtersituacao . ']';
		}

		return $filtersituacao;
	}

	public function setFilterDate($inicialdate, $finaldate)
	{	
		if($this->filters)
		{
			$this->filters = $this->filters . ';dataEmissao[' . $inicialdate . 'TO' . $finaldate . ']';
		}
		else
		{
			$this->filters = 'dataEmissao[' . $inicialdate . 'TO' . $finaldate . ']';
		}
	}

	public function getUrlCurl()
	{
		if($this->filters)
		{
			$this->urlcurl = "{$this->urlapi}/page={$this->page}/{$this->outputType}/&apikey={$this->apikey}&filters={$this->filters}";
		}

		else
		{
			$this->urlcurl = "{$this->urlapi}/page={$this->page}/{$this->outputType}/&apikey={$this->apikey}";
		}

		return $this->urlcurl;
	}

	public function getAllOrders()
	{

		$curl_handle = curl_init();
		curl_setopt($curl_handle, CURLOPT_URL,  $this->getUrlCurl() );
		curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, TRUE);
		$response = curl_exec($curl_handle);
		curl_close($curl_handle);

	    return $response;
	}

	public function getOrders($page = null)
	{
		$this->page = $page;

		$allorders = $this->getAllOrders();
		$allorders = json_decode($allorders, true);

		$pedidos = [];

		if (@$allorders['retorno']['pedidos'])
		{
			foreach ($allorders['retorno']['pedidos'] as $key => $value) {
				$dadosvenda	= array(
					'numero'		=> $value['pedido']['numero'],
					'data' 			=> $value['pedido']['data'],
					'valorfrete'	=> $value['pedido']['valorfrete'],
					'desconto'		=> $value['pedido']['desconto'],
					'totalprodutos' => $value['pedido']['totalprodutos'],
					'totalvenda'	=> $totalvenda = $value['pedido']['totalvenda'],
					'situacao'		=> $value['pedido']['situacao'],
					'formapagamento'=> $formapagamento = $value['pedido']['parcelas']['0']['parcela']['forma_pagamento']['descricao']	);
				
				$cliente = array(
					'nome'		=> $value['pedido']['cliente']['nome'],
					'cidade'	=> $value['pedido']['cliente']['cidade'],
					'estado'	=> $value['pedido']['cliente']['uf']);

				$transporte = array(
					'servico'	=> @$value['pedido']['transporte']['volumes']['0']['volume']['servico'],
					'valorfreteprevisto' => @$value['pedido']['transporte']['volumes']['0']['volume']['valorFretePrevisto']);

				$itens = $value['pedido']['itens'];
				$custototal = 0;

				foreach ($itens as $key => $value) {
					$custototal += $value['item']['quantidade'] * $value['item']['precocusto'];
				}

				$taxa_boleto = 3.49;
				$taxa_cartao = 4.99;

				if ($formapagamento == 'Boleto (Mercado Pago)')
				{
					$custotaxas = $taxa_boleto; 
				}
				if ($formapagamento == 'Cartão de Crédito (Mercado Pago)')
				{
					$custotaxas = floatval($totalvenda) * ($taxa_cartao / 100);
				}

				$pedidos[] = array(
					'dadosvenda'	=> $dadosvenda,
					'cliente'		=> $cliente,
					'transporte'	=> $transporte,
					'custototal'	=> $custototal,
					'taxas'			=> $custotaxas);
			}	
		}

		
		return $pedidos	;
	}

}
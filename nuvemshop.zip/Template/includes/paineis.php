<?php include 'page_title.php'; ?>
<?php page_title('Dashboard', 'Visualize as principais métricas do seu negócio'); ?>

<?php

$inicial = date('d/m/Y');
$final = date('d/m/Y');

if(isset($_GET['datestart']) || isset($_GET['dateend']))
{
	$inicial = $_GET['datestart'];
	$final = $_GET['dateend'];
}
if(isset($_GET['filtro']))
{
	if($_GET['filtro'] == 'dia')
	{
		$inicial = date('d/m/Y');
		$final = date('d/m/Y');
	}
	if ($_GET['filtro'] == 'semana')
	{
		$inicial = date('d/m/Y', strtotime('-7 Days'));
			$final = date('d/m/Y');
	}
	if($_GET['filtro'] == 'mes')
	{
		$inicial = date('01/m/Y');
		$final = date('d/m/Y');
	}
}

$pedidos = new PedidosBling;
$pedidos->setFilterDate($inicial, $final);
$situacao = new SituacoesBling;
$ids = $situacao->getIdsHerdados(array('15', '9'));
$pedidos->setFilterSituacao($ids);

$receitatotal = 0;
$totalfrete = 0;
$custototal = 0;
$descontototal = 0;
$taxastotal = 0;

foreach ($pedidos = $pedidos->getOrders('1') as $value)
{
	$receitatotal += floatval($value['dadosvenda']['totalvenda']);
	$totalfrete += floatval($value['dadosvenda']['valorfrete']);
	$custototal += floatval($value['custototal']);
	$descontototal += floatval($value['dadosvenda']['desconto']);
	$taxastotal += floatval($value['taxas']);
}

$ticketmedio = (count($pedidos) > 0) ? $receitatotal / count($pedidos) : 0;

?>

<?php include "input_date.php" ?>

<div class="lg:flex lg:justify-between mt-4">
	<div class="sm:rounded-lg bg-white shadow px-4 py-5 sm:px-6 w-1/4 mr-4">
	    <h4 class="text-md leading-6 font-small text-gray-900">Receita total</h4>
	    <p class="mt-3 max-w-xl text-2xl font-semibold text-gray-700">R$ <?php echo moeda($receitatotal) ?></p>
	    <p class="text-xs text-gray-400 mt-2">Quantidade de pedidos: <?php echo count($pedidos) ?></p>
	    <p class="text-xs text-gray-400 mt-1">Ticket médio: R$ <?php echo moeda($ticketmedio) ?></p>
  	</div>

  	<div class="sm:rounded-lg bg-white shadow px-4 py-5 sm:px-6 w-1/4 mr-4">
	    <h4 class="text-md leading-6 font-small text-gray-900">Custos</h4>
	    <p class="mt-3 max-w-xl text-2xl font-semibold text-gray-700">R$ <?php echo moeda($custototal + $totalfrete) ?></p>
	    <p class="text-xs text-gray-400 mt-2">Custo de produtos: R$ <?php echo moeda($custototal) ?></p>
	    <p class="text-xs text-gray-400 mt-1">Frete: R$ <?php echo moeda($totalfrete) ?></p>
  	</div>

  	<div class="sm:rounded-lg bg-white shadow px-4 py-5 sm:px-6 w-1/4 mr-4">
	    <h4 class="text-md leading-6 font-small text-gray-900">Despesas</h4>
	    <p class="mt-3 max-w-xl text-2xl font-semibold text-gray-700">R$ <?php echo moeda($taxastotal) ?></p>
	    <p class="text-xs text-gray-400 mt-2">Taxas: R$ <?php echo moeda($taxastotal) ?></p>
	    <p class="text-xs text-gray-400 mt-1">Marketing: R$ <?php  ?></p>
  	</div>

  	<div class="sm:rounded-lg bg-white shadow px-4 py-5 sm:px-6 w-1/4">
	    <h4 class="text-md leading-6 font-small text-gray-900">Lucro</h4>
	    <p class="mt-3 max-w-xl text-2xl font-semibold text-gray-700">R$ <?php echo moeda($receitatotal - $custototal - $totalfrete- $taxastotal)?></p>
  	</div>
</div>
<div class="flex justify-between mt-4">
	<div class="flex">
	<form method="get" action="">
		<button class="inline-flex items-center cursor-pointer h-10 px-4 py-2 rounded-md text-sm font-medium text-white text-gray-800 <?php echo ($_GET['filtro'] == 'dia' ? 'bg-gray-200 border border-transparent shadow-sm' : '') ?>">
	 	<input type="hidden" name="filtro" value="dia">
	 	<input type="submit" value="Hoje" class="cursor-pointer font-semibold">
	  </button>
	</form>

	<form method="get" action="">
		<button class="inline-flex items-center cursor-pointer h-10 ml-2 mr-2 px-4 py-2 rounded-md text-sm font-medium text-white text-gray-800 <?php echo ($_GET['filtro'] == 'semana' ? 'bg-gray-200 border border-transparent shadow-sm' : '') ?>">
	 	<input type="hidden" name="filtro" value="semana">
	 	<input type="submit" value="7 dias" class="cursor-pointer font-semibold">
	  </button>
	</form>

	<form method="get" action="">
		<button class="inline-flex items-center cursor-pointer h-10 ml-2 mr-2 px-4 py-2 rounded-md text-sm font-medium text-white text-gray-800  <?php echo ($_GET['filtro'] == 'mes' ? 'bg-gray-200 border border-transparent shadow-sm' : '') ?>">
	 	<input type="hidden" name="filtro" value="mes">
	 	<input type="submit" value="Mês" class="cursor-pointer font-semibold">
	  </button>
	</form>
</div>
	
	<form method="get" action="" class="flex justify-content items-center">
		  <div class="datepicker relative xl:w-32" data-mdb-toggle-button="false">
		    <input type="text"
		      class="form-control px-4 h-10 py-2 block w-full px-3 text-base font-normal text-gray-700 bg-white border border-solid border-gray-300 rounded-md transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
		      placeholder="Data inicial" value="<?php echo $inicial ?>" name="datestart" data-mdb-toggle="datepicker" />
		  </div>

		  <div class="ml-2">
		  	á
		  </div>

		  <div class="datepicker relative xl:w-32 ml-2" data-mdb-toggle-button="false">
		    <input type="text"
		      class="form-control px-4 h-10 py-2 block w-full px-3 text-base font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded-md transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
		      placeholder="Data final" value="<?php echo $final ?>" name="dateend" data-mdb-toggle="datepicker" />
		  </div>

		  <button class="ml-2 inline-flex items-center px-4 py-2 border border-transparent rounded-md h-10 shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
	        <!-- Heroicon name: solid/check -->
	        <svg class="-ml-1 mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
	          <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" />
	        </svg>
	        <input type="submit" value="Filtrar" class="cursor-pointer">
	    </button>
	</form>
</div>
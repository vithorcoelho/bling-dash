<?php

date_default_timezone_set("America/Sao_Paulo");

define('API_KEY', '3b9b9ec9b01afc1d8a16cb76e6721421ff09ea6dd22277c573a6cda4e8399699fe909e16');
define('API_URL', 'https://bling.com.br/Api/v2/');
define('TOKEN_FACEBOOK', 'EAAKCdrVcBMUBAAkvtKhFw1W2zYHjOvhyityVfAcQrUwtm1UDBgZBnyM45JVcuTUPZBXMXnGdlO4Xhi1EelNI3stk5Y4UH1kZBZAnNZAgGeLU4BRdr586XgNCmGBNhVaukNkrpnVFf9i1mEZAZAcqb2UnjvdPCRaVMS1sc2qCxOgPP9SzLi7Yc3SBq1p0RwZAzrQZD');

